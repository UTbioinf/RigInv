
#include "graph.h"
#include <assert.h>

/*********************** declarations ****************************/

void splitgraph(graph *g, int left_side);
void restoregraph(graph *g);
int ReachedLeaf(graph *g);
void debug(graph *g);



