
#include "graph.h"
#include <assert.h>

/*********************** declarations ****************************/

void splitgraph(graph *g);
void restoregraph(graph *g);
int ReachedLeaf(graph *g);
void debug(graph *g);



