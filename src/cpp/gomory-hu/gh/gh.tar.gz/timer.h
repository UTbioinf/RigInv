/* timing function: difference between two calls is processor time
 * spent by your code (in seconds) 
 */

#ifndef __TIMER_H__
#define __TIMER_H__

float timer(void);

#endif /*__TIMER_H__ */
